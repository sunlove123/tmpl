package org.acme;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import java.sql.Timestamp;

@Entity
@Table(name = "transactions")
public class TransactionEntity extends PanacheEntityBase{
    @Id
    public String tx_id;
    public String acc_id;
    public Timestamp tx_ts;
    public String status;
    public int amount;
    public String merchantname;
    public String merchant_id;
    public String tx_type;
    public String tx_details;
}
