package org.acme;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class TransactionRepository implements PanacheRepository<TransactionEntity> {

   // put your custom logic here as instance methods

   public TransactionEntity findById(String id){
       return find("tx_id", id).firstResult();
   }

}
