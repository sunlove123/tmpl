package org.acme;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import jakarta.inject.Inject;

@Path("/")
public class GreetingResource {
    @Inject
    TransactionRepository txRepository;

    @GET
    @Path("/hello")
    @Produces(MediaType.TEXT_PLAIN)
    public String hello() {
        return "Hello from RESTEasy Reactive";
    }
    
    @GET
    @Path("/tx")
    @Produces(MediaType.APPLICATION_JSON)
    public TransactionEntity tx() {
        return txRepository.findById("e9ef975a-60e5-4308-84be-e2a6d70b5c84");
    }


// e9ef975a-60e5-4308-84be-e2a6d70b5c84 tx id
//  fe6b92dd-7d6d-4677-a457-db3d26bae260 | RPOQ40801609753513 | 2023-01-18 12:58:58 | complete |   1576 
// | Barnes-Williams              | 290-61126-7 | atm      | Law enough we.

}
